# Maximum of an Array

`ArrayUtils.max(nums)` should return the biggest number in the array. It has a bug. For an empty array it should throw `IllegalArgumentException`.

## How to run the tests
```bash
javac -d out src/*.java test/*.java
java -cp out ArrayUtilsTest
```
Works in Terminal, PowerShell, or CMD.
No Maven, no Gradle, no libraries. Plain Java 17+.
