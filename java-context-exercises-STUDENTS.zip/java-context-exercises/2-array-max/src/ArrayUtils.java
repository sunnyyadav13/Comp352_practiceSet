public class ArrayUtils {

    // Return the largest number in the array.
    // Empty array -> throw IllegalArgumentException.
    public static int max(int[] nums) {
        int max = 0;
        for (int n : nums) {
            if (n > max) {
                max = n;
            }
        }
        return max;
    }
}
