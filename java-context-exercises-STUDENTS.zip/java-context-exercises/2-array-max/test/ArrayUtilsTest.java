public class ArrayUtilsTest {
    public static void main(String[] args) {
        Check.equal("max of positives", 9, ArrayUtils.max(new int[]{3, 9, 2}));
        Check.equal("max of one item", 5, ArrayUtils.max(new int[]{5}));
        Check.equal("max of negatives", -1, ArrayUtils.max(new int[]{-7, -1, -3}));

        String result;
        try { ArrayUtils.max(new int[]{}); result = "no exception"; }
        catch (IllegalArgumentException e) { result = "IllegalArgumentException"; }
        Check.equal("empty array throws", "IllegalArgumentException", result);

        Check.done();
    }
}
