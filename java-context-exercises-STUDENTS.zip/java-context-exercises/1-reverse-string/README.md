# Reverse a String

Write `StringUtils.reverse(s)` that returns the string backwards. Example: "hello" -> "olleh".

## How to run the tests
```bash
javac -d out src/*.java test/*.java
java -cp out StringUtilsTest
```
Works in Terminal, PowerShell, or CMD.
No Maven, no Gradle, no libraries. Plain Java 17+.
