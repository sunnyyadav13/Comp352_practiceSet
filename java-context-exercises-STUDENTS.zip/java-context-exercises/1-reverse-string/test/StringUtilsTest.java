public class StringUtilsTest {
    public static void main(String[] args) {
        Check.equal("reverse hello", "olleh", StringUtils.reverse("hello"));
        Check.equal("reverse one char", "a", StringUtils.reverse("a"));
        Check.equal("reverse empty", "", StringUtils.reverse(""));
        Check.equal("reverse with space", "dlrow olleh", StringUtils.reverse("hello world"));
        Check.done();
    }
}
