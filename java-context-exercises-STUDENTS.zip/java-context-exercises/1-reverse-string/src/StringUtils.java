public class StringUtils {

    // Return the string backwards, e.g. "hello" -> "olleh".
    // TODO: not implemented yet.
    public static String reverse(String s) {
        return s;
    }
}
