# Two Sum

`TwoSum.find(nums, target)` returns the indexes of the two numbers that add up to `target`. Example: [2, 7, 11, 15], target 9 -> [0, 1]. It works, but it is slow (checks every pair). Make it faster.

## How to run the tests
```bash
javac -d out src/*.java test/*.java
java -cp out TwoSumTest
```
Works in Terminal, PowerShell, or CMD.
No Maven, no Gradle, no libraries. Plain Java 17+.
