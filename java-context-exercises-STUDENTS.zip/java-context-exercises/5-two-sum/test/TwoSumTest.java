import java.util.Arrays;

public class TwoSumTest {
    public static void main(String[] args) {
        Check.equal("basic", "[0, 1]", Arrays.toString(TwoSum.find(new int[]{2, 7, 11, 15}, 9)));
        Check.equal("middle pair", "[1, 2]", Arrays.toString(TwoSum.find(new int[]{3, 2, 4}, 6)));
        Check.equal("same number twice", "[0, 1]", Arrays.toString(TwoSum.find(new int[]{3, 3}, 6)));
        Check.equal("no pair", "[]", Arrays.toString(TwoSum.find(new int[]{1, 2, 3}, 100)));
        Check.equal("negatives", "[0, 2]", Arrays.toString(TwoSum.find(new int[]{-3, 4, 3, 90}, 0)));
        Check.done();
    }
}
