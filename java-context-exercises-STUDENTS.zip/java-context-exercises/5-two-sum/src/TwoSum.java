public class TwoSum {

    // Return indexes [i, j] (i < j) where nums[i] + nums[j] == target.
    // If no pair exists, return an empty array.
    // Works, but checks every pair: O(n^2).
    public static int[] find(int[] nums, int target) {
        for (int i = 0; i < nums.length; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[i] + nums[j] == target) {
                    return new int[]{i, j};
                }
            }
        }
        return new int[]{};
    }
}
