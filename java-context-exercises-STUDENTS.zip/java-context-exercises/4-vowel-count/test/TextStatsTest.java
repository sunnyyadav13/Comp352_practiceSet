public class TextStatsTest {
    public static void main(String[] args) {
        Check.equal("Hello World", 3, TextStats.countVowels("Hello World"));
        Check.equal("no vowels", 0, TextStats.countVowels("rhythm"));
        Check.equal("all caps", 5, TextStats.countVowels("AEIOU"));
        Check.equal("empty", 0, TextStats.countVowels(""));
        Check.done();
    }
}
