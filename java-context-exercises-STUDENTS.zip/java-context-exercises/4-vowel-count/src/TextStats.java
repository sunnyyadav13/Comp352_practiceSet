public class TextStats {

    // Count vowels a, e, i, o, u (upper or lower case).
    // "Hello World" -> 3
    // TODO: not implemented yet.
    public static int countVowels(String s) {
        return 0;
    }
}
