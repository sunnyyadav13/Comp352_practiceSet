# Count Vowels

`TextStats.countVowels(s)` should return how many vowels (a, e, i, o, u, upper or lower case) are in the string. Example: "Hello World" -> 3.

## How to run the tests
```bash
javac -d out src/*.java test/*.java
java -cp out TextStatsTest
```
Works in Terminal, PowerShell, or CMD.
No Maven, no Gradle, no libraries. Plain Java 17+.
