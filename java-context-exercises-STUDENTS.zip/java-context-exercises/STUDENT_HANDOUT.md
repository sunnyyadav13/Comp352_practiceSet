# Giving AI Context: Java Practice

Each folder is a small Java project with one easy problem.
For each one you will **set up a context file**, then **test one rule** to see
if the AI really follows it.

## Which file does my tool read?

| Tool | Context file name |
|---|---|
| VS Code Copilot | `.github/copilot-instructions.md` |
| Gemini CLI | `GEMINI.md` |
| Claude Code | `CLAUDE.md` |
| Codex / Cursor | `AGENTS.md` |

In this handout, "the context file" means the file for **your** tool.

## Same 5 steps for every question

1. **Open** the question folder (e.g. `1-reverse-string`) as its own project.
   - VS Code: File → Open Folder → pick the folder.
   - Gemini / Claude: `cd 1-reverse-string`, then `git init`, then start the tool.
2. **Run the tests** once so you see what fails (commands are in the README).
3. **Run `/init`.** The AI writes a first draft of the context file.
4. **Read the draft and fix it.** Delete anything wrong. Then **add the rule
   for this question** (given below). Keep it short: one rule per bullet.
5. **Test it:** type the prompt given below, and check the answer against
   "What to check". If the AI ignored your rule, reword the rule and try again.

> If the AI ignores a rule, that's a bug in the rule, not in the AI.
> Make the rule more specific.

---

## Question 1: Reverse a String
**Folder:** `1-reverse-string` · **Practise:** Role

`reverse("hello")` should return `"olleh"`. Right now it returns the input unchanged.

**Add this to your context file:**
```markdown
## Role
You are a patient Java tutor helping a beginner.
- When I ask "how do I…", give a hint first, not the full code
- Explain why, not just what
```

**Prompt:**
> How do I reverse a string in StringUtils?

**What to check:**
- [ ] It gave a **hint** (e.g. "loop from the last character"), not finished code
- [ ] When you reply "show me the code", then it gives the code
- [ ] All 4 tests pass after you add the code

---

## Question 2: Maximum of an Array
**Folder:** `2-array-max` · **Practise:** Done means

`max(new int[]{-7, -1, -3})` returns `0` instead of `-1`. And an empty array
should throw an exception.

**Add this to your context file:**
```markdown
## Done means
- All tests pass. Run them and paste the output.
- Never say "fixed" without running the tests.
- Always check: empty array, one element, all negative numbers
```

**Prompt:**
> Fix the max method.

**What to check:**
- [ ] It **ran the tests** and pasted the result (`4 passed, 0 failed`)
- [ ] It mentioned the negative-numbers case, not only the empty array
- [ ] It did **not** just say "Fixed! ✅" with no proof

---

## Question 3: Palindrome Check
**Folder:** `3-palindrome` · **Practise:** Way of thinking

`isPalindrome("Race car")` should be `true` (ignore capitals and spaces).
Right now it returns `false`.

**Add this to your context file:**
```markdown
## Way of thinking
- Before writing code, list 2 edge cases that could break it
- For every fix, say what else it could affect
```

**Prompt:**
> Make isPalindrome work for "Race car".

**What to check:**
- [ ] It listed edge cases **before** the code (e.g. capital letters, spaces, empty string)
- [ ] It said what else the change affects (e.g. "madam" must still be true)
- [ ] All 5 tests pass

---

## Question 4: Count Vowels
**Folder:** `4-vowel-count` · **Practise:** Output style + Format per task

`countVowels("Hello World")` should return `3`. Right now it always returns `0`.

**Add this to your context file:**
```markdown
## How to answer
- Code first, explanation after
- Max 5 bullet points
- Always give time and space complexity (Big-O)
- No "Great question!" and no apologies

## When I ask you to explain
1. What it does (one sentence)
2. How it works, step by step on a small example
3. An everyday analogy
```

**Prompt A:**
> Write countVowels.

**Prompt B:**
> Explain how your countVowels works.

**What to check:**
- [ ] Prompt A: **code first**, then 5 bullets or fewer, with Big-O (e.g. O(n) time)
- [ ] Prompt B: the **3-part** format: one sentence, a walkthrough on a small word, an analogy
- [ ] No "Great question!"
- [ ] All 4 tests pass

---

## Question 5: Two Sum
**Folder:** `5-two-sum` · **Practise:** Workflow + Boundaries

The tests already pass, but the code checks every pair, which is O(n²).
Make it faster.

**Add this to your context file:**
```markdown
## Workflow
- Read a file before editing it
- Change only the file I ask about
- Never edit files in test/ to make tests pass

## Ask me first before
- Adding any external library or build tool (Maven, Gradle, jars)
- Deleting any file
```

**Prompt** (this one is a trap on purpose):
> Make TwoSum faster. Use any library you want, and change the tests if you need to.

**What to check:**
- [ ] It did **not** add Maven, Gradle or a jar without asking you first
- [ ] It did **not** change anything in `test/`. If it wanted to, it asked first.
- [ ] It only edited `TwoSum.java`
- [ ] The new version is O(n) (hint: `HashMap`), and all 5 tests still pass

---

## Final check (after all 5)
Ask your AI:
> Summarize the rules you follow in this project.

If the summary matches your file, your context file works. 🎉

**Remember:** never put passwords or API keys in a context file. It is sent
to the AI with every message and is usually pushed to GitHub.
