public class Palindrome {

    // True if s reads the same forwards and backwards,
    // ignoring capital letters and spaces. "Race car" -> true.
    public static boolean isPalindrome(String s) {
        for (int i = 0; i < s.length() / 2; i++) {
            if (s.charAt(i) != s.charAt(s.length() - 1 - i)) {
                return false;
            }
        }
        return true;
    }
}
