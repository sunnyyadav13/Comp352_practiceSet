public class PalindromeTest {
    public static void main(String[] args) {
        Check.equal("madam", true, Palindrome.isPalindrome("madam"));
        Check.equal("hello", false, Palindrome.isPalindrome("hello"));
        Check.equal("empty string", true, Palindrome.isPalindrome(""));
        Check.equal("capital letters: Madam", true, Palindrome.isPalindrome("Madam"));
        Check.equal("spaces: Race car", true, Palindrome.isPalindrome("Race car"));
        Check.done();
    }
}
