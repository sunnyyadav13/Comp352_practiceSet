# Palindrome Check

`Palindrome.isPalindrome(s)` should return true if the text reads the same forwards and backwards, ignoring capital letters and spaces. Example: "Race car" -> true. It has bugs.

## How to run the tests
```bash
javac -d out src/*.java test/*.java
java -cp out PalindromeTest
```
Works in Terminal, PowerShell, or CMD.
No Maven, no Gradle, no libraries. Plain Java 17+.
